package com.example.KoeAdmin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
